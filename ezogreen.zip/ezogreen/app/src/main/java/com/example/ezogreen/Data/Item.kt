package com.example.ezogreen.Data

data class Item(

    val textView: String?,
    val textView1: String?,
    val textView2: String?,
    val textView3: String?,
    val imageview: String?,

) {

}
