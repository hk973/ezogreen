package com.example.ezogreen
var Name = "HariSamAtharva"
var Edittextvalue=""
var id=""